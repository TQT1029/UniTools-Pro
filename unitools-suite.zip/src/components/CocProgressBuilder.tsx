import React, { useState, useEffect } from 'react';
import { CocPotion } from '../types';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';
import { Sliders, Plus, Trash2, ShieldAlert, Sparkles, TrendingDown } from 'lucide-react';

export default function CocProgressBuilder() {
  const [days, setDays] = useState(10);
  const [hours, setHours] = useState(0);
  const [minutes, setMinutes] = useState(0);

  // Potions Stack queuing
  const [buffQueue, setBuffQueue] = useState<CocPotion[]>([
    { name: 'Builder Potion x10', multiplier: 10, duration: 1 }
  ]);

  const [potName, setPotName] = useState('Builder Potion x10');
  const [potMult, setPotMult] = useState(10);
  const [potDur, setPotDur] = useState(1);
  const [report, setReport] = useState('');
  const [chartData, setChartData] = useState<any[]>([]);

  const formatDuration = (secs: number) => {
    const dd = Math.floor(secs / 86400);
    const hh = Math.floor((secs % 86450) / 3600);
    const mm = Math.floor((secs % 3600) / 60);
    return `${dd} ngày ${hh} giờ ${mm} phút`;
  };

  const handleAddBuff = () => {
    if (!potName.trim() || potMult <= 0 || potDur <= 0) return;
    setBuffQueue(prev => [...prev, { name: potName, multiplier: potMult, duration: potDur }]);
  };

  const handleClearBuffs = () => {
    setBuffQueue([]);
  };

  const handleDeleteBuff = (index: number) => {
    setBuffQueue(prev => prev.filter((_, idx) => idx !== index));
  };

  useEffect(() => {
    const originalSeconds = days * 86400 + hours * 3600 + minutes * 60;
    if (originalSeconds <= 0) {
      setReport('Vui lòng cấu hình thời lượng nâng cấp thi công công trình hợp lệ.');
      setChartData([]);
      return;
    }

    let remainingWork = originalSeconds;
    let currentRealTime = 0.0;
    const trajectory = [{ x: 0, y: Number((originalSeconds / 3600).toFixed(1)) }];

    buffQueue.forEach((buff) => {
      if (remainingWork <= 0) return;
      const buffDurationSec = buff.duration * 3600;
      const maxWorkDone = buffDurationSec * buff.multiplier;

      let realTimeSpent;
      if (remainingWork >= maxWorkDone) {
        remainingWork -= maxWorkDone;
        realTimeSpent = buffDurationSec;
      } else {
        realTimeSpent = remainingWork / buff.multiplier;
        remainingWork = 0.0;
      }
      currentRealTime += realTimeSpent;
      trajectory.push({
        x: Number((currentRealTime / 3600).toFixed(1)),
        y: Number((remainingWork / 3600).toFixed(1))
      });
    });

    if (remainingWork > 0) {
      currentRealTime += remainingWork;
      remainingWork = 0.0;
      trajectory.push({
        x: Number((currentRealTime / 3600).toFixed(1)),
        y: 0
      });
    }

    const savedSecs = Math.max(0, originalSeconds - currentRealTime);
    const completionDate = new Date(Date.now() + currentRealTime * 1000);
    const ratio = originalSeconds > 0 ? (savedSecs / originalSeconds) * 100 : 0;

    setReport(
      `• Tổng thời gian thực tế ngoài đời thực: ${formatDuration(currentRealTime)}\n` +
      `• Quỹ thời gian thi công rút ngắn: ${formatDuration(savedSecs)}\n` +
      `• Tỷ lệ rút gọn tối ưu hóa: Tăng tốc ${ratio.toFixed(1)}%\n` +
      `• Dự kiến hoàn thành nâng cấp: ${completionDate.toLocaleTimeString()} - ${completionDate.toLocaleDateString('vi-VN')}`
    );

    setChartData(trajectory);
  }, [days, hours, minutes, buffQueue]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
      {/* LEFT COLUMN: BUILDER SETTINGS */}
      <div className="lg:col-span-4 flex flex-col gap-6">
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 shadow-sm">
          <h3 className="text-base font-bold text-emerald-600 dark:text-emerald-400 border-b pb-3 mb-4 flex items-center gap-2">
            <Sliders className="w-5 h-5 text-emerald-500" /> Thời gian Nâng Cấp Công Trình
          </h3>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Ngày</span>
              <input
                type="number"
                min={0}
                value={days}
                onChange={(e) => setDays(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 dark:bg-slate-900 border text-xs p-2.5 rounded-lg text-center font-bold"
              />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Giờ</span>
              <input
                type="number"
                min={0}
                value={hours}
                onChange={(e) => setHours(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 dark:bg-slate-900 border text-xs p-2.5 rounded-lg text-center font-bold"
              />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Phút</span>
              <input
                type="number"
                min={0}
                value={minutes}
                onChange={(e) => setMinutes(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-slate-50 dark:bg-slate-900 border text-xs p-2.5 rounded-lg text-center font-bold"
              />
            </div>
          </div>
        </div>

        {/* POTION BUILDER SETUP */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 shadow-sm">
          <h3 className="text-base font-bold text-teal-600 dark:text-teal-400 border-b pb-3 mb-4 flex items-center gap-2">
            <Plus className="w-5 h-5 text-teal-500" /> Cấu Hình Thuốc Tăng Tốc (Buffs)
          </h3>
          <div className="space-y-3">
            <div>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Tên loại Buff Potion</span>
              <input
                type="text"
                value={potName}
                onChange={(e) => setPotName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-900 border text-xs px-3 py-2 rounded-xl font-bold"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Hệ số multiplier (x)</span>
                <input
                  type="number"
                  min={1}
                  value={potMult}
                  onChange={(e) => setPotMult(Math.max(1, parseInt(e.target.value) || 12))}
                  className="w-full bg-slate-50 dark:bg-slate-900 border text-xs p-2.5 rounded-lg text-center font-bold text-emerald-500"
                />
              </div>
              <div>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Thời lượng (Giờ)</span>
                <input
                  type="number"
                  min={0.1}
                  step={0.5}
                  value={potDur}
                  onChange={(e) => setPotDur(Math.max(0.1, parseFloat(e.target.value) || 1))}
                  className="w-full bg-slate-50 dark:bg-slate-900 border text-xs p-2.5 rounded-lg text-center font-bold text-teal-500"
                />
              </div>
            </div>
            <button
              onClick={handleAddBuff}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 px-4 rounded-xl text-xs flex items-center justify-center gap-1 transition-all shadow-sm active:scale-95"
            >
              <Plus className="w-4 h-4" /> Thêm Vào Hàng Đợi Buffs
            </button>
          </div>
        </div>

        {/* ACTIVE BUFFS LIST */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between border-b pb-2.5 mb-2.5">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4 text-emerald-500" /> Hộp thuốc tăng tốc đang xếp xếp
            </span>
            <button
              onClick={handleClearBuffs}
              className="text-[10px] text-rose-500 font-bold hover:underline flex items-center gap-0.5"
            >
              <Trash2 className="w-3" /> Xóa tất cả
            </button>
          </div>
          <div className="space-y-1.5 max-h-[120px] overflow-y-auto custom-scrollbar border rounded-xl p-2 bg-slate-50/50 dark:bg-slate-900/10">
            {buffQueue.length === 0 ? (
              <span className="text-slate-400 italic text-center block text-[11px] py-4">Hàng đợi rỗng...</span>
            ) : (
              buffQueue.map((item, idx) => (
                <div key={idx} className="flex justify-between items-center bg-white dark:bg-slate-800 p-2 rounded-lg border text-xs font-semibold shadow-xs">
                  <span>{item.name} (x{item.multiplier} trong {item.duration}h)</span>
                  <button onClick={() => handleDeleteBuff(idx)} className="text-rose-500 font-black hover:text-rose-700 select-none text-base leading-none">&times;</button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: RECHARTS TRAJECTORY GRAPH */}
      <div className="lg:col-span-8 bg-white dark:bg-slate-800 rounded-2xl border border-slate-205 dark:border-slate-705 p-5 shadow-sm flex flex-col justify-between min-h-[500px]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3 mb-4">
          <span className="text-xs font-extrabold uppercase tracking-widest text-slate-500 flex items-center gap-1.5">
            <TrendingDown className="w-4 h-4 text-emerald-500" /> Quỹ đạo dọn dẹp thời hạn thi công (Burn-down)
          </span>
          <span className="text-[10px] font-mono text-slate-400 font-bold">Thực tế game</span>
        </div>

        <div className="flex-1 min-h-[300px] relative w-full flex items-center justify-center bg-slate-50/20 rounded-xl p-2 border">
          {chartData.length === 0 ? (
            <span className="text-xs text-slate-400 italic">Thiết lập thời lượng thi công gốc để xem đồ thị...</span>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ left: -10, right: 10, top: 15, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" opacity={0.1} />
                <XAxis dataKey="x" label={{ value: 'Giờ ngoài đời thực', position: 'insideBottomRight', offset: -10, style: { fontSize: '9px', fill: '#64748b' } }} fontSize={9} />
                <YAxis label={{ value: 'Công việc còn lại (Giờ)', angle: -90, position: 'insideLeft', style: { fontSize: '9px', fill: '#64748b' } }} fontSize={9} />
                <Tooltip
                  formatter={(value) => [`${value} giờ`, 'Công việc còn lại']}
                  labelFormatter={(label) => `Thời gian thực: ${label} giờ`}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '12px',
                    color: '#f8fafc',
                    fontSize: '11px'
                  }}
                />
                <Line type="linear" dataKey="y" stroke="#10b981" strokeWidth={3} dot />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* VERBOSE METRIC REPORT */}
        <div className="mt-4 bg-emerald-50/30 dark:bg-slate-905 border border-emerald-100 dark:border-slate-755 rounded-xl p-4 font-mono text-xs text-emerald-900 dark:text-emerald-300 leading-relaxed whitespace-pre-line shadow-inner">
          <span className="font-bold block mb-1 text-slate-700 dark:text-slate-300 uppercase tracking-widest text-[10px]"><Sparkles className="w-3.5 h-3.5 inline mr-1 text-teal-400" /> Thống kê mô phóng nâng cấp :</span>
          {report}
        </div>
      </div>
    </div>
  );
}
