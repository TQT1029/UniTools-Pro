import React, { useState, useEffect, useRef } from 'react';
import { TOOL_CATEGORIES, ALL_TOOLS } from '../config/tools';
import { ToolDefinition } from '../types';
import {
  Search,
  Moon,
  Sun,
  Menu,
  X,
  Command,
  Binary,
  FileText,
  Wand2,
  Sliders,
  Wrench,
  Play,
  Layers,
  Calendar,
  TrendingUp,
  Timer,
  Activity,
  ChevronRight,
  Sparkles,
  Languages,
  Volume2
} from 'lucide-react';

interface LayoutProps {
  activeToolId: string;
  onSelectTool: (id: string) => void;
  children: React.ReactNode;
}

export default function Layout({ activeToolId, onSelectTool, children }: LayoutProps) {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Sync / initialize theme preferences
  useEffect(() => {
    const saved = localStorage.getItem('unitools_theme');
    if (saved === 'dark') {
      document.documentElement.classList.add('dark');
      setTheme('dark');
    } else {
      document.documentElement.classList.remove('dark');
      setTheme('light');
    }
  }, []);

  const toggleTheme = () => {
    const next = theme === 'light' ? 'dark' : 'light';
    setTheme(next);
    localStorage.setItem('unitools_theme', next);
    if (next === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  // Bind Cmd/Ctrl + K command palette keyboard shortcuts
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(prev => !prev);
      } else if (e.key === 'Escape') {
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, []);

  useEffect(() => {
    if (searchOpen) {
      setTimeout(() => searchInputRef.current?.focus(), 80);
    }
  }, [searchOpen]);

  const mapIcon = (iconName: string, isActive?: boolean) => {
    const p = { className: "w-4 h-4" };
    if (isActive) {
      switch (iconName) {
        case 'languages': return <Languages {...p} className="w-4 h-4 text-white" />;
        case 'volume2': return <Volume2 {...p} className="w-4 h-4 text-white" />;
        case 'activity': return <Activity {...p} className="w-4 h-4 text-white" />;
        case 'binary': return <Binary {...p} className="w-4 h-4 text-white" />;
        case 'file-text': return <FileText {...p} className="w-4 h-4 text-white" />;
        case 'wand': return <Wand2 {...p} className="w-4 h-4 text-white" />;
        case 'sliders': return <Sliders {...p} className="w-4 h-4 text-white" />;
        case 'wrench': return <Wrench {...p} className="w-4 h-4 text-white" />;
        case 'play': return <Play {...p} className="w-4 h-4 text-white animate-pulse" />;
        case 'layers': return <Layers {...p} className="w-4 h-4 text-white" />;
        case 'calendar': return <Calendar {...p} className="w-4 h-4 text-white" />;
        case 'trending-up': return <TrendingUp {...p} className="w-4 h-4 text-white" />;
        case 'stopwatch': return <Timer {...p} className="w-4 h-4 text-white" />;
        default: return <Wrench {...p} className="w-4 h-4 text-white" />;
      }
    }
    switch (iconName) {
      case 'languages': return <Languages {...p} className="w-4 h-4 text-indigo-500 animate-pulse" />;
      case 'volume2': return <Volume2 {...p} className="w-4 h-4 text-teal-500" />;
      case 'activity': return <Activity {...p} className="w-4 h-4 text-emerald-500" />;
      case 'binary': return <Binary {...p} className="w-4 h-4 text-purple-500" />;
      case 'file-text': return <FileText {...p} className="w-4 h-4 text-cyan-500" />;
      case 'wand': return <Wand2 {...p} className="w-4 h-4 text-pink-500" />;
      case 'sliders': return <Sliders {...p} className="w-4 h-4 text-blue-500" />;
      case 'wrench': return <Wrench {...p} className="w-4 h-4 text-amber-500" />;
      case 'play': return <Play {...p} className="w-4 h-4 text-indigo-500 animate-pulse" />;
      case 'layers': return <Layers {...p} className="w-4 h-4 text-teal-500" />;
      case 'calendar': return <Calendar {...p} className="w-4 h-4 text-orange-500" />;
      case 'trending-up': return <TrendingUp {...p} className="w-4 h-4 text-emerald-500" />;
      case 'stopwatch': return <Timer {...p} className="w-4 h-4 text-rose-500" />;
      default: return <Wrench {...p} />;
    }
  };

  // Filter list of tools for Command Palette
  const filteredTools = React.useMemo(() => {
    const q = searchQuery.toLowerCase().trim();
    if (!q) return ALL_TOOLS.slice(0, 5);
    return ALL_TOOLS.filter(t => t.name.toLowerCase().includes(q) || t.description.toLowerCase().includes(q));
  }, [searchQuery]);

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-905 text-slate-800 dark:text-slate-100 transition-colors duration-200">
      
      {/* SIDEBAR FOR DESKTOP */}
      <aside className="hidden lg:flex flex-col w-72 bg-white dark:bg-slate-800 border-r border-slate-200 dark:border-slate-705 shadow-xs shrink-0 select-none">
        {/* Brand header */}
        <div className="p-6 border-b border-slate-100 dark:border-slate-755 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-gradient-to-tr from-cyan-500 to-indigo-600 p-2 rounded-xl shadow-md text-white">
              <Command className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-widest text-slate-900 dark:text-white uppercase">UniTools Suite</h1>
              <span className="text-[10px] font-bold text-[#117a8b] uppercase tracking-wider block">Production Standard</span>
            </div>
          </div>
        </div>

        {/* Search quick button */}
        <div className="p-4 border-b border-slate-100 dark:border-slate-755">
          <button
            onClick={() => setSearchOpen(true)}
            className="w-full bg-slate-100 dark:bg-slate-900 border hover:border-slate-300 dark:hover:border-slate-700 text-slate-400 dark:text-slate-500 font-bold py-2 px-3.5 rounded-xl text-xs flex items-center justify-between group transition-all"
          >
            <div className="flex items-center gap-2">
              <Search className="w-3.5 h-3.5 group-hover:text-cyan-500 transition-colors" />
              <span>Tìm tiện ích nhanh...</span>
            </div>
            <kbd className="bg-white dark:bg-slate-800 border px-1.5 py-0.5 rounded text-[9px] font-sans shadow-sm">⌘ K</kbd>
          </button>
        </div>

        {/* Dynamic Category sections list */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-5">
          {TOOL_CATEGORIES.map(cat => {
            const catTools = ALL_TOOLS.filter(t => t.category === cat.id);
            return (
              <div key={cat.id} className="space-y-1.5">
                <span className="text-[10px] font-extrabold uppercase text-slate-400 tracking-widest pl-1">
                  {cat.name}
                </span>
                <div className="space-y-1 pl-1">
                  {catTools.map(tool => (
                    <button
                      key={tool.id}
                      onClick={() => onSelectTool(tool.id)}
                      className={`w-full text-left px-3 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between group transition-all ${activeToolId === tool.id ? 'bg-[#117a8b] text-white shadow-sm font-bold' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700/40'}`}
                    >
                      <div className="flex items-center gap-2.5 truncate">
                        {mapIcon(tool.icon, activeToolId === tool.id)}
                        <span className="truncate">{tool.name}</span>
                      </div>
                      <ChevronRight className={`w-3.5 h-3.5 shrink-0 transition-transform ${activeToolId === tool.id ? 'text-white' : 'text-slate-304 opacity-0 group-hover:opacity-100'}`} />
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Workspace details footer block */}
        <div className="p-4 border-t border-slate-150 dark:border-slate-755 text-[10.5px] text-slate-400 font-bold select-none text-center bg-slate-50/50 dark:bg-slate-900/10">
          <span>Hỗ trợ Web Worker & Recharts Engine</span>
        </div>
      </aside>

      {/* MOBILE SIDEBAR PANEL */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-40 lg:hidden flex">
          <div className="fixed inset-0 bg-black/60 backdrop-blur-xs" onClick={() => setSidebarOpen(false)}></div>
          <aside className="relative w-80 max-w-sm bg-white dark:bg-slate-800 border-r flex flex-col p-6 shadow-2xl h-full animate-slide-in">
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute right-4 top-4 p-2 rounded-lg text-slate-400 focus:outline-none"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="flex items-center gap-2 mb-6">
              <Command className="w-6 h-6 text-[#117a8b]" />
              <h2 className="text-base font-black uppercase text-slate-900 dark:text-white">UniTools Suite</h2>
            </div>
            <div className="flex-1 overflow-y-auto space-y-4">
              {TOOL_CATEGORIES.map(cat => {
                const catTools = ALL_TOOLS.filter(t => t.category === cat.id);
                return (
                  <div key={cat.id} className="space-y-1.5">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">{cat.name}</span>
                    <div className="space-y-1.5">
                      {catTools.map(tool => (
                        <button
                          key={tool.id}
                          onClick={() => {
                            onSelectTool(tool.id);
                            setSidebarOpen(false);
                          }}
                          className={`w-full text-left px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 ${activeToolId === tool.id ? 'bg-[#117a8b] text-white shadow' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700/40'}`}
                        >
                          {mapIcon(tool.icon, activeToolId === tool.id)}
                          <span className="truncate">{tool.name}</span>
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </aside>
        </div>
      )}

      {/* MAIN CONTAINER PAGE */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* NAV ROUTE HEADER */}
        <header className="h-16 bg-white dark:bg-slate-800 border-b border-slate-200 dark:border-slate-705 px-6 flex items-center justify-between shadow-xs z-10 select-none shrink-0">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 rounded-xl bg-slate-50 dark:bg-slate-755 text-slate-600 dark:text-slate-200"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="hidden lg:flex items-center gap-2 text-xs font-semibold text-slate-400">
              <span>UniTools</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-300" />
              <span className="text-slate-800 dark:text-slate-200 font-extrabold capitalize">
                {ALL_TOOLS.find(t => t.id === activeToolId)?.name}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setSearchOpen(true)}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-705 text-slate-500 dark:text-slate-300 transition-colors border"
              title="Tìm tiện ích nhanh (Cmd + K)"
            >
              <Search className="w-4 h-4" />
            </button>
            <button
              onClick={toggleTheme}
              className="p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 dark:bg-slate-705 text-slate-500 dark:text-slate-300 transition-colors border"
              title="Chuyển chế độ Giao Diện"
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-amber-400" />}
            </button>
            <span className="text-[10px] items-center gap-1 bg-gradient-to-r from-emerald-500/10 to-indigo-500/10 dark:text-emerald-300 text-slate-800 font-extrabold px-3 py-1.5 rounded-full border border-emerald-500/20 shadow-xs hidden sm:flex">
              <Sparkles className="w-3.5 h-3.5 text-indigo-500 animate-pulse" /> Production Ready
            </span>
          </div>
        </header>

        {/* CONTAINER VIEWPORTS PORTAL */}
        <main className="flex-1 p-6 md:p-8 lg:p-10 max-w-7xl w-full mx-auto overflow-y-auto custom-scrollbar">
          {children}
        </main>
      </div>

      {/* COMMAND PALETTE MODAL (Ctrl / Cmd + K) */}
      {searchOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-xs" onClick={() => setSearchOpen(false)}></div>
          <div className="relative w-full max-w-xl bg-white dark:bg-slate-800 rounded-3xl border shadow-2xl p-6 text-slate-800 dark:text-white animate-scale-up border-slate-205 dark:border-slate-705">
            <div className="flex items-center gap-2 border-b pb-4 mb-4">
              <Command className="w-5 h-5 text-indigo-500 animate-spin" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Gõ tên tính năng hoặc từ khóa mô tả..."
                className="w-full bg-transparent text-sm focus:outline-none placeholder-slate-401 pl-1"
              />
              <button onClick={() => setSearchOpen(false)} className="text-[10px] font-bold text-slate-400 border px-2 py-1 rounded-xl bg-slate-50 dark:bg-slate-700">ESC</button>
            </div>

            {/* Hits suggestions viewport */}
            <div className="space-y-2 max-h-[300px] overflow-y-auto custom-scrollbar">
              {filteredTools.length === 0 ? (
                <div className="text-slate-400 italic text-center py-6 text-xs">Không khớp kết quả tiện ích UniTools nào...</div>
              ) : (
                filteredTools.map(tool => (
                  <button
                    key={tool.id}
                    onClick={() => {
                      onSelectTool(tool.id);
                      setSearchOpen(false);
                      setSearchQuery('');
                    }}
                    className="w-full text-left p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-slate-755 border border-transparent hover:border-slate-100 dark:hover:border-slate-700 flex items-center justify-between group transition-all"
                  >
                    <div className="flex items-center gap-3">
                      <div className="bg-slate-50 dark:bg-slate-700 p-2 rounded-xl border">
                        {mapIcon(tool.icon)}
                      </div>
                      <div>
                        <span className="text-xs font-bold block group-hover:text-[#117a8b] transition-colors">{tool.name}</span>
                        <span className="text-[10.5px] text-slate-400 block">{tool.description}</span>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-300 opacity-0 group-hover:opacity-100" />
                  </button>
                ))
              )}
            </div>
            <div className="text-[10px] font-bold text-slate-401 text-center mt-4 border-t pt-2 flex items-center justify-center gap-3">
              <span>↑↓ Di chuyển</span>
              <span>• Nhấp để kích hoạt ngay lập tức</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
