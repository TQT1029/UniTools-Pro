import React, { useState, useEffect, useRef } from 'react';
import { create, all } from 'mathjs';
import katex from 'katex';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { MathFunction } from '../types';
import { Calculator, Play, RotateCcw, Copy, Check, Eye, EyeOff, Trash2, Plus } from 'lucide-react';

const math = create(all);

interface MathCASGrapherProps {
  onFormulaSelect?: (formula: string) => void;
}

export default function MathCASGrapher({ onFormulaSelect }: MathCASGrapherProps) {
  const [rawInput, setRawInput] = useState('x^2 - 5x + 6');
  const [terminalOutput, setTerminalOutput] = useState('Hệ thống CAS/Đồ thị sẵn sàng...');
  const [isCopied, setIsCopied] = useState(false);
  const [graphMode, setGraphMode] = useState<'2d' | '3d'>('2d');
  
  // View domains for 2D graphing pan / zoom
  const [domainX, setDomainX] = useState<[number, number]>([-8, 8]);
  const [domainY, setDomainY] = useState<[number, number]>([-8, 8]);

  // Functions Registry for 2D graphing
  const [functions, setFunctions] = useState<MathFunction[]>([
    { id: 'f1', expr: 'x^2 - 2', color: '#6366f1', visible: true },
    { id: 'f2', expr: 'sin(x) * 3', color: '#10b981', visible: true },
    { id: 'f3', expr: 'cos(x)^2', color: '#f43f5e', visible: false }
  ]);
  const [newFuncExpr, setNewFuncExpr] = useState('');

  // Calculations history
  const [history, setHistory] = useState<string[]>([
    'x^2 - 5x + 6',
    'det([[1, 2], [3, 4]])',
    'sin(x) * x',
    'derivative("x^3 + 2x", "x")',
    'simplify("2x + 5x - 3")'
  ]);

  // View references
  const wysiwygRef = useRef<HTMLDivElement>(null);
  const canvas3DRef = useRef<HTMLCanvasElement>(null);

  // 3D rotation fields
  const [theta, setTheta] = useState(0.6);
  const [phi, setPhi] = useState(0.8);
  const isDragging3D = useRef(false);
  const lastMousePos3D = useRef({ x: 0, y: 0 });

  // Virtual keyboard schema
  const keyboardSchema = {
    numeric: {
      name: 'Số học',
      keys: [
        { label: '7', token: '7' }, { label: '8', token: '8' }, { label: '9', token: '9' }, { label: '÷', token: '/' },
        { label: '4', token: '4' }, { label: '5', token: '5' }, { label: '6', token: '6' }, { label: '×', token: '*' },
        { label: '1', token: '1' }, { label: '2', token: '2' }, { label: '3', token: '3' }, { label: '−', token: '-' },
        { label: '0', token: '0' }, { label: '.', token: '.' }, { label: 'π', token: 'pi' }, { label: '+', token: '+' },
        { label: 'e', token: 'e' }, { label: '(', token: '(' }, { label: ')', token: ')' }, { label: 'Ans', token: 'Ans' }
      ]
    },
    algebra: {
      name: 'Giải tích & Đại số',
      keys: [
        { label: 'x', token: 'x' }, { label: 'y', token: 'y' }, { label: 'z', token: 'z' }, { label: 'x²', token: '^2' },
        { label: 'x³', token: '^3' }, { label: 'xⁿ', token: '^' }, { label: '√', token: 'sqrt(' }, { label: 'abs', token: 'abs(' },
        { label: 'log', token: 'log(' }, { label: 'ln', token: 'log(' }, { label: 'sin', token: 'sin(' }, { label: 'cos', token: 'cos(' },
        { label: 'tan', token: 'tan(' }, { label: 'd/dx', token: 'derivative(' }, { label: 'Simplify', token: 'simplify(' }, { label: 'Expand', token: 'expand(' }
      ]
    },
    matrix: {
      name: 'Ma trận & Logic',
      keys: [
        { label: '[ ]', token: '[[]]' }, { label: 'Det', token: 'det(' }, { label: 'Inv', token: 'inv(' }, { label: 'Trans', token: 'transpose(' },
        { label: 'Dot', token: 'dot(' }, { label: 'Cross', token: 'cross(' }, { label: 'Mean', token: 'mean(' }, { label: 'Std', token: 'std(' },
        { label: '∧', token: ' and ' }, { label: '∨', token: ' or ' }, { label: '¬', token: 'not ' }, { label: '∈', token: ' in ' }
      ]
    }
  };

  const [activeKeyboardTab, setActiveKeyboardTab] = useState<keyof typeof keyboardSchema>('numeric');

  // Trigger update when input changes
  useEffect(() => {
    evaluateInputExpression();
  }, [rawInput, functions]);

  // Draw 3D wireframe Graph when custom function or orientations change
  useEffect(() => {
    if (graphMode === '3d') {
      draw3DGraph();
    }
  }, [graphMode, rawInput, theta, phi, functions]);

  const handleVirtualKeyPress = (token: string) => {
    if (token === 'Ans') {
      setRawInput(prev => prev + '6'); // default dummy variable value
    } else {
      setRawInput(prev => prev + token);
    }
  };

  const evaluateInputExpression = () => {
    if (!wysiwygRef.current) return;
    try {
      if (rawInput.trim().length > 0) {
        // Parse math string to KaTeX syntax formula
        const node = math.parse(rawInput);
        const tex = node.toTex({ parenthesis: 'keep', implicit: 'hide' });
        
        katex.render(tex, wysiwygRef.current, {
          displayMode: true,
          throwOnError: false
        });

        // Try evaluating
        const result = node.evaluate({ x: 2, y: 3 }); // test evaluation variables
        let formattedResult = '';
        if (typeof result === 'function') {
          formattedResult = `[Compiled Function Target]\nHàm số đã được biên dịch thành công. Có thể vẽ đồ thị 2D & 3D.`;
        } else {
          formattedResult = `• Chuỗi kết quả: ${math.format(result, { precision: 12 })}\n• Định dạng số thực (với x=2, y=3): ${Number(result)}`;
        }
        setTerminalOutput(formattedResult);
      } else {
        katex.render('\\square', wysiwygRef.current, {
          displayMode: true,
          throwOnError: false
        });
        setTerminalOutput('Casio CAS Engine sẵn sàng...');
      }
    } catch (err: any) {
      try {
        katex.render(rawInput, wysiwygRef.current, {
          displayMode: true,
          throwOnError: false
        });
      } catch (e) {}
      setTerminalOutput(`[Cú pháp chưa hoàn chỉnh hoặc phát hiện lỗi]\n${err.message}`);
    }
  };

  const executeCasResult = () => {
    if (!rawInput.trim()) return;
    try {
      const node = math.parse(rawInput);
      const res = node.evaluate({ x: 2, y: 3 });
      const finalStr = math.format(res, { precision: 10 });
      setTerminalOutput(`• Biểu thức: ${rawInput}\n• Kết quả (x=2, y=3): ${finalStr}`);
      
      // Save history safely
      if (!history.includes(rawInput)) {
        setHistory(prev => [rawInput, ...prev.slice(0, 9)]);
      }
    } catch (err: any) {
      setTerminalOutput(`[Lỗi thực thi CAS]\n${err.message}`);
    }
  };

  const handleCopyResult = () => {
    navigator.clipboard.writeText(terminalOutput);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // 2D chart data assembly
  const generate2DChartData = () => {
    const dataPoints = [];
    const minX = domainX[0];
    const maxX = domainX[1];
    const steps = 80;
    const stepSize = (maxX - minX) / steps;

    // Compile active functions
    const compiledFuncs = functions.map(f => {
      if (!f.visible) return null;
      try { return { id: f.id, fn: math.compile(f.expr) }; } catch (e) { return null; }
    }).filter(Boolean) as { id: string; fn: math.EvalFunction }[];

    // Compile currently typing active rawInput as temporary dotted line if it of x variable
    let activeInputCompiled: math.EvalFunction | null = null;
    if (rawInput.trim() && !rawInput.includes('y')) {
      try { activeInputCompiled = math.compile(rawInput); } catch (e) {}
    }

    for (let i = 0; i <= steps; i++) {
      const x = minX + i * stepSize;
      const row: Record<string, any> = { x: Number(x.toFixed(2)) };

      compiledFuncs.forEach(cf => {
        try {
          const val = cf.fn.evaluate({ x });
          if (typeof val === 'number' && isFinite(val) && !isNaN(val)) {
            row[cf.id] = val;
          }
        } catch (e) {}
      });

      if (activeInputCompiled) {
        try {
          const val = activeInputCompiled.evaluate({ x });
          if (typeof val === 'number' && isFinite(val) && !isNaN(val)) {
            row['activeInput'] = val;
          }
        } catch (e) {}
      }

      dataPoints.push(row);
    }
    return dataPoints;
  };

  // 2D Navigation Controls
  const panGraph = (direction: 'left' | 'right' | 'up' | 'down') => {
    const shiftX = (domainX[1] - domainX[0]) * 0.25;
    const shiftY = (domainY[1] - domainY[0]) * 0.25;
    if (direction === 'left') {
      setDomainX([domainX[0] - shiftX, domainX[1] - shiftX]);
    } else if (direction === 'right') {
      setDomainX([domainX[0] + shiftX, domainX[1] + shiftX]);
    } else if (direction === 'up') {
      setDomainY([domainY[0] + shiftY, domainY[1] + shiftY]);
    } else if (direction === 'down') {
      setDomainY([domainY[0] - shiftY, domainY[1] - shiftY]);
    }
  };

  const zoomGraph = (factor: number) => {
    const centerX = (domainX[0] + domainX[1]) / 2;
    const centerY = (domainY[0] + domainY[1]) / 2;
    const halfWidth = ((domainX[1] - domainX[0]) * factor) / 2;
    const halfHeight = ((domainY[1] - domainY[0]) * factor) / 2;
    setDomainX([centerX - halfWidth, centerX + halfWidth]);
    setDomainY([centerY - halfHeight, centerY + halfHeight]);
  };

  const reset2DView = () => {
    setDomainX([-8, 8]);
    setDomainY([-8, 8]);
  };

  const autoFit2DView = () => {
    const data = generate2DChartData();
    let minY = Infinity;
    let maxY = -Infinity;
    data.forEach(row => {
      Object.keys(row).forEach(key => {
        if (key !== 'x') {
          const val = row[key];
          if (typeof val === 'number' && isFinite(val)) {
            if (val < minY) minY = val;
            if (val > maxY) maxY = val;
          }
        }
      });
    });

    if (minY !== Infinity && maxY !== -Infinity) {
      const padding = Math.max(1, (maxY - minY) * 0.1);
      setDomainY([minY - padding, maxY + padding]);
    } else {
      setDomainY([-8, 8]);
    }
  };

  const addNewFunction = () => {
    if (!newFuncExpr.trim()) return;
    const colors = ['#f43f5e', '#a855f7', '#06b6d4', '#eab308', '#ec4899'];
    const color = colors[functions.length % colors.length];
    const newFunc: MathFunction = {
      id: 'f_' + Date.now(),
      expr: newFuncExpr,
      color,
      visible: true
    };
    setFunctions(prev => [...prev, newFunc]);
    setNewFuncExpr('');
  };

  const deleteFunction = (id: string) => {
    setFunctions(prev => prev.filter(f => f.id !== id));
  };

  const toggleFunctionVisibility = (id: string) => {
    setFunctions(prev => prev.map(f => f.id === id ? { ...f, visible: !f.visible } : f));
  };

  // 3D Isometric Projection Plotting
  const draw3DGraph = () => {
    const canvas = canvas3DRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.offsetWidth || 400;
    const height = canvas.offsetHeight || 300;
    canvas.width = width;
    canvas.height = height;

    ctx.clearRect(0, 0, width, height);

    // Compile the 3D function (either current input if contains y, or the main function)
    let compiled3D: math.EvalFunction | null = null;
    let textToCompile = 'x^2 + y^2';
    if (rawInput.includes('y')) {
      textToCompile = rawInput;
    } else if (functions[0]) {
      textToCompile = functions[0].expr;
    }

    try {
      compiled3D = math.compile(textToCompile);
    } catch (e) {
      try {
        compiled3D = math.compile('x^2 - y^2');
      } catch (err) {}
    }

    if (!compiled3D) return;

    // Direct 3D wireframe matrix projection
    const project = (x3d: number, y3d: number, z3d: number) => {
      const cosT = Math.cos(theta);
      const sinT = Math.sin(theta);
      const cosP = Math.cos(phi);
      const sinP = Math.sin(phi);

      const x1 = x3d * cosT - y3d * sinT;
      const y1 = x3d * sinT + y3d * cosT;
      const z1 = y1 * sinP + z3d * cosP;
      const x2 = x1;

      // Scaling factor: 16
      return {
        x: width / 2 + x2 * 15,
        y: height / 2 - z1 * 15
      };
    };

    const steps = 24;
    const size = 6;
    const stepSize = (size * 2) / steps;

    // Draw grid wires
    ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
    ctx.lineWidth = 1;

    // Draw along X lines
    for (let i = 0; i <= steps; i++) {
      const x = -size + i * stepSize;
      ctx.beginPath();
      for (let j = 0; j <= steps; j++) {
        const y = -size + j * stepSize;
        try {
          const z = Number(compiled3D.evaluate({ x, y })) * 0.4;
          if (isFinite(z) && !isNaN(z)) {
            const pt = project(x, y, z);
            if (j === 0) ctx.moveTo(pt.x, pt.y);
            else ctx.lineTo(pt.x, pt.y);
          }
        } catch (e) {}
      }
      ctx.stroke();
    }

    // Draw along Y lines
    for (let j = 0; j <= steps; j++) {
      const y = -size + j * stepSize;
      ctx.beginPath();
      for (let i = 0; i <= steps; i++) {
        const x = -size + i * stepSize;
        try {
          const z = Number(compiled3D.evaluate({ x, y })) * 0.4;
          if (isFinite(z) && !isNaN(z)) {
            const pt = project(x, y, z);
            if (i === 0) ctx.moveTo(pt.x, pt.y);
            else ctx.lineTo(pt.x, pt.y);
          }
        } catch (e) {}
      }
      ctx.stroke();
    }
  };

  const handleMouseDown3D = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDragging3D.current = true;
    lastMousePos3D.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove3D = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging3D.current) return;
    const deltaX = e.clientX - lastMousePos3D.current.x;
    const deltaY = e.clientY - lastMousePos3D.current.y;
    
    setTheta(prev => prev + deltaX * 0.01);
    setPhi(prev => prev - deltaY * 0.01);
    
    lastMousePos3D.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUpOrLeave3D = () => {
    isDragging3D.current = false;
  };

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 h-full items-stretch">
      {/* LEFT COLUMN: VIRTUAL CASIO CAS KEYBOARD */}
      <div className="xl:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col overflow-hidden shadow-sm">
        <div className="bg-slate-50 dark:bg-slate-900/60 p-4 border-b border-slate-200 dark:border-slate-700/80 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-cyan-500" /> Bàn Phím Casio CAS Pro v3.0
          </span>
          <div className="flex bg-slate-200 dark:bg-slate-700/80 p-0.5 rounded-lg text-[10px] font-bold">
            <button
              onClick={() => setGraphMode('2d')}
              className={`px-3 py-1 rounded transition-colors ${graphMode === '2d' ? 'bg-white dark:bg-slate-600 shadow-sm text-cyan-600 dark:text-cyan-300' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
            >
              Đồ thị 2D
            </button>
            <button
              onClick={() => setGraphMode('3d')}
              className={`px-3 py-1 rounded transition-colors ${graphMode === '3d' ? 'bg-white dark:bg-slate-600 shadow-sm text-cyan-600 dark:text-cyan-300' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}
            >
              Không gian 3D
            </button>
          </div>
        </div>

        {/* Keyboard Sub Tabs */}
        <div className="flex border-b border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-800/20 overflow-x-auto custom-scrollbar">
          {Object.keys(keyboardSchema).map((key) => (
            <button
              key={key}
              onClick={() => setActiveKeyboardTab(key as any)}
              className={`px-4 py-2.5 text-[11px] font-bold whitespace-nowrap border-b-2 transition-all ${
                activeKeyboardTab === key
                  ? 'border-cyan-500 text-cyan-600 dark:text-cyan-400 bg-slate-100/60 dark:bg-slate-700/20'
                  : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
              }`}
            >
              {keyboardSchema[key as keyof typeof keyboardSchema].name}
            </button>
          ))}
        </div>

        {/* Keyboard Keys Grid */}
        <div className="grid grid-cols-4 gap-2 p-4 flex-1 bg-slate-50/30 dark:bg-slate-800/10 content-start overflow-y-auto custom-scrollbar min-h-[300px]">
          {keyboardSchema[activeKeyboardTab].keys.map((k, idx) => (
            <button
              key={idx}
              onClick={() => handleVirtualKeyPress(k.token)}
              className="bg-white hover:bg-slate-50 dark:bg-slate-700/70 dark:hover:bg-slate-600/95 text-slate-800 dark:text-slate-200 border border-slate-200/80 dark:border-slate-600/60 py-3 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center justify-center font-mono active:scale-95"
            >
              {k.label}
            </button>
          ))}
          <button
            onClick={() => setRawInput('')}
            className="col-span-2 bg-rose-500 hover:bg-rose-600 text-white font-bold py-3 rounded-xl text-xs shadow-sm transition-all text-center active:scale-95"
          >
            CLEAR (C)
          </button>
          <button
            onClick={() => setRawInput(prev => prev.slice(0, -1))}
            className="col-span-2 bg-slate-400 hover:bg-slate-500 dark:bg-slate-600 dark:hover:bg-slate-500 text-white font-bold py-3 rounded-xl text-xs shadow-sm transition-all text-center active:scale-95"
          >
            BACKSPACE (⌫)
          </button>
        </div>
      </div>

      {/* MIDDLE COLUMN: FORMULA SCREEN & TERMINAL RESPONSE */}
      <div className="xl:col-span-4 flex flex-col gap-6 h-full justify-between">
        {/* WYSIWYG Math Screen */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 flex flex-col gap-3 shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Play className="w-3 h-3 text-cyan-500" /> Màn hình Biểu thức KaTeX (Live Screen)
          </span>
          <div className="border border-slate-200 dark:border-slate-950 bg-slate-100 dark:bg-slate-900 rounded-2xl p-6 min-h-[110px] flex items-center justify-center overflow-x-auto shadow-inner custom-scrollbar select-all">
            <div ref={wysiwygRef} className="text-slate-900 dark:text-white text-xl font-mono text-center"></div>
          </div>
          <div>
            <input
              type="text"
              value={rawInput}
              onChange={(e) => {
                setRawInput(e.target.value);
                if (onFormulaSelect) onFormulaSelect(e.target.value);
              }}
              placeholder="Nhập biểu thức (ví dụ: x^2 - sin(x) hoặc det([[1, 2], [3, 4]]))"
              className="w-full bg-slate-50 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-xl px-4 py-3 text-xs font-mono focus:ring-2 focus:ring-cyan-500 focus:outline-none text-slate-800 dark:text-slate-100 placeholder:text-slate-400/85"
            />
          </div>
          <button
            onClick={executeCasResult}
            className="w-full bg-cyan-600 hover:bg-cyan-700 text-white font-bold py-2.5 rounded-xl shadow-md transition-all text-sm flex items-center justify-center gap-2 active:scale-95"
          >
            <Check className="w-4 h-4" /> THỰC THI CAS SOLVER
          </button>
        </div>

        {/* CAS Outputs Terminal */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 flex flex-col flex-1 overflow-hidden shadow-sm">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700/70 pb-3 mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Kết Quả CAS Output Terminal
            </span>
            <button
              onClick={handleCopyResult}
              className="text-[10px] bg-slate-100 hover:bg-slate-200 dark:bg-slate-700 dark:hover:bg-slate-600 text-slate-600 dark:text-slate-300 px-2.5 py-1 rounded-md transition-all flex items-center gap-1 font-bold"
            >
              {isCopied ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
              {isCopied ? 'Đã sao chép' : 'Sao chép'}
            </button>
          </div>
          <div className="flex-1 bg-slate-900 dark:bg-slate-950 text-emerald-400 p-4 rounded-xl font-mono text-xs overflow-y-auto custom-scrollbar border border-slate-250 dark:border-slate-900 shadow-inner">
            <pre className="whitespace-pre-wrap break-all leading-relaxed font-sans">{terminalOutput}</pre>
          </div>
        </div>

        {/* History Area */}
        <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 p-5 flex flex-col h-[180px] overflow-hidden shadow-sm">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100 dark:border-slate-700 pb-2 mb-2 flex items-center gap-1.5">
            <RotateCcw className="w-3 h-3 text-cyan-500" /> Nhật Ký Phép Tính & Cú Pháp Mẫu
          </span>
          <div className="space-y-1.5 overflow-y-auto custom-scrollbar flex-1 text-xs font-mono">
            {history.map((hist, index) => (
              <div
                key={index}
                onClick={() => {
                  setRawInput(hist);
                  if (onFormulaSelect) onFormulaSelect(hist);
                }}
                className="bg-slate-50/50 dark:bg-slate-700/30 p-2 rounded-lg border border-slate-100 dark:border-slate-700/60 cursor-pointer hover:bg-cyan-50/50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 truncate transition-all font-bold"
                title={hist}
              >
                {hist}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* RIGHT COLUMN: GRAPH VISUALIZATION */}
      <div className="xl:col-span-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 flex flex-col overflow-hidden h-full shadow-sm">
        <div className="p-4 border-b border-slate-200 dark:border-slate-700/80 bg-slate-50 dark:bg-slate-900/60 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-600 dark:text-slate-400 flex items-center gap-1.5">
            {graphMode === '2d' ? (
              <svg className="w-4 h-4 text-cyan-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 3v18h18M18 9l-5 5-2-2-4 4"/></svg>
            ) : (
              <svg className="w-4 h-4 text-purple-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>
            )}
            {graphMode === '2d' ? 'Đồ thị Trực Quan 2D' : 'Đồ Thị Bề Mặt 3D Wireframe'}
          </span>
        </div>

        {/* 2D Mode */}
        {graphMode === '2d' && (
          <div className="flex-1 p-4 flex flex-col gap-4 overflow-hidden">
            <div className="flex-1 bg-slate-50 dark:bg-slate-900/20 rounded-xl border border-slate-200/60 dark:border-slate-700/80 min-h-[220px] flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={generate2DChartData()} margin={{ top: 15, right: 15, left: -20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" opacity={0.15} />
                  <XAxis dataKey="x" type="number" domain={domainX} fontSize={10} tickLine={false} allowDataOverflow />
                  <YAxis type="number" domain={domainY} fontSize={10} tickLine={false} allowDataOverflow />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1e293b',
                      borderColor: '#475569',
                      borderRadius: '8px',
                      color: '#f8fafc',
                      fontSize: '11px'
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: '10px' }} />
                  {functions.map((f) => f.visible && (
                    <Line
                      key={f.id}
                      type="linear"
                      dataKey={f.id}
                      stroke={f.color}
                      name={`y = ${f.expr}`}
                      dot={false}
                      strokeWidth={3}
                    />
                  ))}
                  {rawInput.trim() && !rawInput.includes('y') && (
                    <Line
                      type="linear"
                      dataKey="activeInput"
                      stroke="#8b5cf6"
                      name={`Đầu vào: y = ${rawInput}`}
                      dot={false}
                      strokeWidth={3.5}
                      strokeDasharray="4 4"
                    />
                  )}
                </LineChart>
              </ResponsiveContainer>
            </div>

            {/* Interactive pan/zoom controller */}
            <div className="grid grid-cols-4 sm:grid-cols-4 lg:grid-cols-8 gap-1 p-2 bg-slate-100 dark:bg-slate-900/60 rounded-xl border border-slate-200/50 dark:border-slate-700/50 text-[10px] font-bold">
              <button onClick={() => panGraph('left')} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">◀ Trái</button>
              <button onClick={() => panGraph('right')} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">▶ Phải</button>
              <button onClick={() => panGraph('up')} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">▲ Trên</button>
              <button onClick={() => panGraph('down')} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">▼ Dưới</button>
              <button onClick={() => zoomGraph(0.75)} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">🔍 + (In)</button>
              <button onClick={() => zoomGraph(1.33)} className="bg-white dark:bg-slate-800 hover:bg-cyan-50 dark:hover:bg-slate-755 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 transition-all text-center">🔍 - (Out)</button>
              <button onClick={reset2DView} className="bg-white dark:bg-slate-800 hover:bg-rose-50 dark:hover:bg-rose-950/20 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-rose-550 transition-all text-center">⟲ Reset</button>
              <button onClick={autoFit2DView} className="bg-white dark:bg-slate-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/20 py-1.5 px-0.5 rounded-lg border border-slate-200 dark:border-slate-700 text-emerald-555 transition-all text-center">↕ Fit</button>
            </div>

            {/* Functions Manager inside 2D chart */}
            <div className="h-[150px] border-t border-slate-100 dark:border-slate-700 pt-3 flex flex-col">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                Hệ Thống Quản Lý Lớp Đồ Thị Đa Chức Năng
              </span>
              <div className="space-y-1.5 overflow-y-auto custom-scrollbar flex-1 pr-1">
                {functions.map((f) => (
                  <div
                    key={f.id}
                    className="flex items-center justify-between bg-slate-50 dark:bg-slate-700/40 p-2 rounded-xl border border-slate-100 dark:border-slate-700/80"
                  >
                    <div className="flex items-center gap-2 flex-1 min-w-0">
                      <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: f.color }}></span>
                      <span className="text-xs font-mono font-bold text-slate-700 dark:text-slate-300 truncate">
                        y = {f.expr}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => toggleFunctionVisibility(f.id)}
                        className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                        title="Bật/Tắt hiển thị lớp"
                      >
                        {f.visible ? <Eye className="w-3.5 h-3.5 text-cyan-500" /> : <EyeOff className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        onClick={() => deleteFunction(f.id)}
                        className="text-slate-400 hover:text-rose-500 p-1"
                        title="Xóa lớp"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 mt-2">
                <input
                  type="text"
                  value={newFuncExpr}
                  onChange={(e) => setNewFuncExpr(e.target.value)}
                  placeholder="Thêm hàm số (ví dụ: x^3 - 3x)..."
                  className="flex-1 bg-slate-50 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-lg px-2.5 py-1 text-xs font-mono focus:outline-none"
                />
                <button
                  onClick={addNewFunction}
                  className="bg-cyan-600 hover:bg-cyan-700 text-white rounded-lg px-2 text-xs flex items-center justify-center gap-1 transition-all"
                >
                  <Plus className="w-3.5 h-3.5" /> Thêm
                </button>
              </div>
            </div>
          </div>
        )}

        {/* 3D Mode */}
        {graphMode === '3d' && (
          <div className="flex-1 p-4 flex flex-col gap-3 overflow-hidden">
            <div className="flex-1 relative bg-slate-900 rounded-2xl overflow-hidden min-h-[250px] flex items-center justify-center shadow-inner border border-slate-950">
              <canvas
                ref={canvas3DRef}
                onMouseDown={handleMouseDown3D}
                onMouseMove={handleMouseMove3D}
                onMouseUp={handleMouseUpOrLeave3D}
                onMouseLeave={handleMouseUpOrLeave3D}
                className="w-full h-full absolute inset-0 cursor-grab active:cursor-grabbing"
              ></canvas>
            </div>
            <div className="text-[10px] text-slate-400 text-center py-2 bg-slate-950 rounded-lg border border-slate-900 font-semibold font-mono uppercase tracking-wider">
              ✥ Isometric 3D Space &mdash; Kéo và di chuột để xoay ma trận không gian
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
